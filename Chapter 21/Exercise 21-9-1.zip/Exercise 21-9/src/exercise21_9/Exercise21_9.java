/* John Macdonald
 * January 5, 2023
 * 
 * This code asks for the states capital. The code will also
 * count the capitals that are answered correctly and display
 * the capital of the state if answered incorrectly. This code
 * was modified to use maps instead of the multidimensional
 * string array
 * */

package exercise21_9;

import java.util.*;

public class Exercise21_9 {
  public static void main(String[] args) {
    String[][] stateCapital = { 
      {"Alabama", "Montgomery"},      {"Alaska", "Juneau"},
      {"Arizona", "Phoenix"},         {"Arkansas", "Little Rock"},
      {"California", "Sacramento"},   {"Colorado", "Denver"},
      {"Connecticut", "Hartford"},    {"Delaware", "Dover"},
      {"Florida", "Tallahassee"},     {"Georgia", "Atlanta"},
      {"Hawaii", "Honolulu"},         {"Idaho", "Boise"},
      {"Illinois", "Springfield"},    {"Indiana", "Indianapolis"},
      {"Iowa", "Des Moines"},         {"Kansas", "Topeka"},
      {"Kentucky", "Frankfort"},      {"Louisiana", "Baton Rouge"},
      {"Maine", "Augusta"},           {"Maryland", "Annapolis"},
      {"Massachusettes", "Boston"},   {"Michigan", "Lansing"},
      {"Minnesota", "Saint Paul"},    {"Mississippi", "Jackson"},
      {"Missouri", "Jefferson City"}, {"Montana", "Helena"},
      {"Nebraska", "Lincoln"},        {"Nevada", "Carson City"},
      {"New Hampshire", "Concord"},   {"New Jersey", "Trenton"},
      {"New York", "Albany"},         {"New Mexico", "Santa Fe"},
      {"North Carolina", "Raleigh"},  {"North Dakota", "Bismarck"},
      {"Ohio", "Columbus"},           {"Oklahoma", "Oklahoma City"},
      {"Oregon", "Salem"},            {"Pennsylvania", "Harrisburg"},
      {"Rhode Island", "Providence"}, {"South Carolina", "Columbia"},
      {"South Dakota", "Pierre"},     {"Tennessee", "Nashville"},
      {"Texas", "Austin"},            {"Utah", "Salt Lake City"},
      {"Vermont", "Montpelier"},      {"Virginia", "Richmond"},
      {"Washington", "Olympia"},      {"West Virginia", "Charleston"},
      {"Wisconsin", "Madison"},       {"Wyoming", "Cheyenne"}
    };
    
    //stateCapital multidimentional array converted into
    //two hash maps. mapStates and mapCapitals
    HashMap mapStates = new HashMap();
    for (int i = 0; i < stateCapital.length; i++) {
    	mapStates.put(i, stateCapital[i][0]);
    }
    
    HashMap mapCapitals = new HashMap();
    for(int i = 0; i < stateCapital.length; i++) {
    	mapCapitals.put(i, stateCapital[i][1]);
    }
    
    Scanner input = new Scanner(System.in);
    
    int correctCount = 0;
    
    int leftover = stateCapital.length - 1;
	    
    for (int i = 0; i < stateCapital.length; i++) {
      // Prompt the user with a question    	

    	System.out.print("What is the capital of " + mapStates.get(leftover) + "?");
    	String capital = input.nextLine().trim().toLowerCase();
    	
    	if(capital.toLowerCase().equals(((String) mapCapitals.get(leftover)).toLowerCase())) {
    	System.out.println("Your anser is correct");
    	correctCount++;
    	}
    	else
    		System.out.println("The correct anser should be " + mapCapitals.get(leftover));
    	
    	leftover--;
    	
    }//for loop end

    System.out.println("The correct count is " + correctCount);
    
}//main method end
}//class Exercise21_9 end