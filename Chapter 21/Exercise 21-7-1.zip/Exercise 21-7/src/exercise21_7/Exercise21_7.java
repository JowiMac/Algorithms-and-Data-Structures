/* John Macdonald, January 4, 2023
 * 
 * This code finds the occurrences of
 * words in the string labeled text and
 * lists them in ascending order
 * 
 * Question
 * What would be wrong if you stored the instances of WordOccurrence
 * 			in a tree set?
 * 
 * Answer
 * If the instances of WordOccurrence was stored in a tree set then
 * 			it would try to sort the list of words only, making the
 * 			list of words and occurrences not in ascending order by
 * 			the count of the words themselves.
 * 
 * */

package exercise21_7;

import java.util.*;

public class Exercise21_7 {
public static void main(String[] args) {

// Set text in a string
String text = "Good morning. Have a good class. " +
"Have a good visit. Have fun!";

// Create a HashMap to hold words as key and count as value
HashMap<String, Integer> map = new HashMap<>();
String[] words = text.split("[\\s+\\p{P}]");

String word;
int count;

ArrayList list = new ArrayList();

for (int i = 0; i < words.length; i++) {

	String key = words[i].toLowerCase();

if (key.length() > 0) {

	if (!map.containsKey(key)) {
		map.put(key, 1);
	}//nested if end

	else {
		int value = map.get(key);
		value++;
		map.put(key, value);
		
	}//else end

}//if end

}//for loop end


map.forEach((k, v) -> list.add(new WordOccurrence(k,v)));



Collections.sort(list);

// Display key and value for each entry
map.forEach((k, v) -> System.out.println(k + "\t" + v));

System.out.println();

ArrayList sorty = (ArrayList) list.clone();

list.clear();

//This is my printing of the arraylist
for(int k = 0; k < sorty.size(); k++) {

for(int j = 0; j < sorty.size(); j++) {	
	
for(int i = 0; i < sorty.size(); i++) {

	
	
	if(i+1 == sorty.size()) {
		list.add(sorty.get(i));
		break;
	}
	
	else if ((((WordOccurrence) sorty.get(i)).countComp())
		.compareTo((((WordOccurrence) sorty.get(i+1)).countComp())) == 1) {
		list.add(sorty.get(i + 1));
	}
	else if ((((WordOccurrence) sorty.get(i)).countComp())
			.compareTo((((WordOccurrence) sorty.get(i+1)).countComp())) == -1) {
		list.add(sorty.get(i));
		}

	else {
		list.add(sorty.get(i));
		}

//if compareTo returns a 1 the first number is bigger than the second
//if compareTo returns a 0 both numbers are equal
//if compareTo returns a -1 the second number is bigger than the first
	
}//for loop i end

}//for loop j end

System.out.println(list.get(k).toString());

}//for loop k end

}//main method end
}//class Exercise21_7 end