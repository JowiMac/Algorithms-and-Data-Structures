package exercise21_7;

import java.util.*;
import java.lang.Comparable;

public class WordOccurrence
implements Comparable<WordOccurrence>
{

	String word;
	int count;
	
	public WordOccurrence(String k, int v) {
	this.word = k;
	this.count = v;
	}
	
	@Override
	public int compareTo(WordOccurrence o) {
		if(this.count > o.count)
			return 1;
		else if(this.count < o.count)
			return -1;
		else return 0;
	}
	
	public Integer countComp() {
		return count;
	}
	
	@Override
	public String toString() {
		return (word + "\t" + count);
	}

}
