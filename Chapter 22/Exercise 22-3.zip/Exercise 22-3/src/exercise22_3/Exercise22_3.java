/* John Macdonald
 * Jan. 12 2023
 * 
 * This program tests the second string whether
 * it is a substring of the first string or not.
 * 
 * Time complexity is O(n)
 * */



package exercise22_3;

import java.util.Scanner;

public class Exercise22_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter string s1: ");
		String s1 = input.next();
		System.out.print("Enter string s2: ");
		String s2 = input.next();
		
		//dont use indexOf method in the string class
		//Time complexity O(n) is using only one for loop
		
		int iterate = 0;
		int match = 0;
		
		for(int i = 0; i < s1.length(); i++) {
			
			if(s1.charAt(i) == s2.charAt(iterate) && iterate == 0) {
				iterate++;
				match = i;
			}
			else if(s1.charAt(i) == s2.charAt(iterate)) {
				iterate++;
			}
			else {
			}
		}
		
		System.out.print("Matched at index " + match);
		
	}//main method end
}//class Exercise22_3 end
