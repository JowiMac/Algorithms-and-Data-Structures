/* John Macdonald
 * Jan. 11 2023
 * 
 * This code displays the maximum consecutive
 * increasingly ordered substring.
 * 
 * Time complexity of my program is O(n)
 * */

package exercise22_1;

import java.util.Scanner;

public class Exercise22_1 {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a string: ");
		
		String UserInput = input.next();
	
		String clear = "";

		
		char subTemp = UserInput.charAt(0);
		
		String temporary = "";
		
		String subTot = "";
		
		int iterate = 0;

		//find substring max
		for(int i = 1; i < UserInput.length(); i++) {
			char temp = UserInput.charAt(i-1);
			char UserAt = UserInput.charAt(i);
			
			if(temp < UserAt && i == 1) {
				subTot = "" + temp + UserAt;
				iterate++;
				
			}//if end
			
			else if(temp < UserAt && subTot.charAt(iterate) == temp) {
				subTot = subTot + UserAt;
				iterate++;
			}
			else {
				if(subTot.charAt(0) <= UserAt) {
					temporary = subTot;
					subTot = "" + UserAt;
					iterate = 0;
				}//if end
				else {
					System.out.print("hi");
					iterate = 0;
				}//else end
			}//else end
			
		}//for loop end
		
		if(temporary.length() > subTot.length()) {
				subTot = temporary;
		}//if end
		
		System.out.print("Maximum consecutive substring is " + subTot);
	}//main method end
}//class Exercise22_1 end
