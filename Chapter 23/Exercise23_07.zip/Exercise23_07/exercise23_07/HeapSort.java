package exercise23_07;
/* John Macdonald
 * Jan. 13 2023
 * 
 * This code turns the integer array into a minimum heap.
 * I modified this code.
 * 
 * */


public class HeapSort {
	/** Heap sort method */
	public static <E extends Comparable<E>> void heapSort(E[] list) {
		// Create a Heap of integers
		Heap<E> heap = new Heap<>();

		// Add elements to the heap
		for (int i = 0; i < list.length; i++)
			heap.add(list[i]);

		// Remove elements from the heap
		for (int i = list.length - 1; i >= 0; i--)
			list[i] = heap.remove();
	}
	
	/** A test method */
	public static void main(String[] args) {
		Integer[] list = {-44, -5, -3, 3, 3, 1, -4, 0, 1, 2, 4, 5, 53}; 
					   //{-44, -5, -4, -3, 0, 1, 1, 2, 3, 3, 4, 5, 53} this is the sorted list
		heapSort(list);
		for (int i = 0; i < list.length; i++)
			System.out.print(list[i] + " ");
	
	}//main method end
}//class HeapSort end