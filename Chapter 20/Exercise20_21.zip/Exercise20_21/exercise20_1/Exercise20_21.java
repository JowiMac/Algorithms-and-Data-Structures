package exercise20_1;

/*
Author: John Macdonald
Date: December 20, 2022

Description: I, John, modified this code to sort
a list of objects using comparator
*/
import java.util.Comparator;

public class Exercise20_21 {
  public static void main(String[] args) {
    GeometricObject[] list = {new Circle(5), new Rectangle(4, 5),
        new Circle(5.5), new Rectangle(2.4, 5), new Circle(0.5), 
        new Rectangle(4, 65), new Circle(4.5), new Rectangle(4.4, 1),
        new Circle(6.5), new Rectangle(4, 5)};
    for(int i = 0; i < list.length; i++) {
      selectionSort(list, new GeometricObjectComparator());
      }
      for(int i = 0; i < list.length; i++)
    	  System.out.println(list[i].getArea() + " ");
      
      System.out.println();      

    Circle[] list1 = {new Circle(2), new Circle(3), new Circle(2),
      new Circle(5), new Circle(6), new Circle(1), new Circle(2),
      new Circle(3), new Circle(14), new Circle(12)};
    for(int i = 0; i < list1.length; i++) {
    selectionSort(list1, new GeometricObjectComparator());
    }
    for (int i = 0; i < list1.length; i++)
      System.out.println(list1[i].getArea() + " ");
  }//main method end



//This was added by me from the assignment on canvas
public static <E> void selectionSort(E[] list, Comparator<? super E> comparator) {
	
	for(int i = 0; i < list.length - 1; i++) {
	
	if(comparator.compare(list[i], list[i + 1]) > 0) {
		E great = list[i];
		E less = list[i + 1];
				
		E[] listSort = list;

	listSort[i] = (E) less;
	listSort[i + 1] = (E) great;

	list = (E[]) listSort;
	
	}// if statement end
	
	}// for loop i end

}//selectionSort method end

}//class Exercise20_1 end