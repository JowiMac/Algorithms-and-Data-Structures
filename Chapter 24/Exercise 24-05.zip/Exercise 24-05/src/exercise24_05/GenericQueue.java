package exercise24_05;

import java.util.LinkedList;

public class GenericQueue<E> extends LinkedList{
		
		static LinkedList list = new LinkedList<>();
				
		public void enqueue(E e) {
			list.addLast(e);
		}
		
		public E dequeue() {
			return (E) list.removeFirst();
		}
	}
