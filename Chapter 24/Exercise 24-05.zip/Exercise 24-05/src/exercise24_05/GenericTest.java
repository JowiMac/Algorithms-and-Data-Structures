/* John Macdonald
 * Dec. 21, 2022
 * 
 * This code shows inheritance from GenericQueue,
 * enqueues and dequeues elements, and prints what
 * happens
 * */

package exercise24_05;

public class GenericTest extends GenericQueue {
	public static void main(String[] args) {
		String hi = "hi";
		String hello = "hello";
		String jam = "jam";
		
		GenericQueue genericQueue = new GenericQueue();
		
		genericQueue.enqueue(hi);
		genericQueue.enqueue(hello);
		genericQueue.enqueue(jam);
		System.out.println(GenericQueue.list);
		
		System.out.println();
		
		genericQueue.dequeue();
		
		System.out.println(list);
	}
}
